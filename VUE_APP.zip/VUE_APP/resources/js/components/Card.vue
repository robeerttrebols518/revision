<template>
    <div>
        <h1>Card.vue</h1>
    </div>
</template>
