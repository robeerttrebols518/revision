<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  </head>
  <body>
    <!--  navbar  -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Navbar</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Features</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Pricing</a>
              </li>
              <li class="nav-item">
                <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
              </li>
            </ul>
          </div>
        </div>
    </nav>
    <!--  Thumnnail  -->
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-12 mb-4 mb-lg-0">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/187.webp"
                    class="card-img-top"
                    alt="Peaks Against the Starry Sky"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0 d-none d-lg-block">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/188.webp"
                    class="card-img-top"
                    alt="Bridge Over Water"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0 d-none d-lg-block">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/189.webp"
                    class="card-img-top"
                    alt="Purbeck Heritage Coast"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12 mb-4 mb-lg-0">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/187.webp"
                    class="card-img-top"
                    alt="Peaks Against the Starry Sky"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0 d-none d-lg-block">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/188.webp"
                    class="card-img-top"
                    alt="Bridge Over Water"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0 d-none d-lg-block">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/189.webp"
                    class="card-img-top"
                    alt="Purbeck Heritage Coast"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
<?php /**PATH /var/www/html/laravel/laravel-27032023-a/VUE_APP/resources/views/app.blade.php ENDPATH**/ ?>