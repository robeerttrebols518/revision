<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductController extends Controller
{
    //index
    public function index(){

    }

    //store
    public function store(){

    }

    //show
    public function show(){

    }

    //update
    public function update(){

    }

    //destroy
    public function destroy(){

    }
}
