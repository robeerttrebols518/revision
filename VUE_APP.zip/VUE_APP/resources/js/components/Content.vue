<template>
    <section class="content">
        <slot />
    </section>
</template>
