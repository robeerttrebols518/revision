<template>
    <div>
        <h1>NavItem.vue</h1>
    </div>
</template>
