<template>
    <div>
        <h1>Sidebar.vue</h1>
    </div>
</template>
