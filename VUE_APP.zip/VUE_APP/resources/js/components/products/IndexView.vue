<template>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Navbar</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <router-link :to="{name: 'home'}" class="nav-link active" aria-current="page">Home</router-link>
              </li>
              <li class="nav-item">
                <router-link :to="{name: 'indexProduct'}" class="nav-link" aria-current="page">Productos</router-link>
              </li>
              <li class="nav-item">
                <router-link :to="{name: 'contact'}" class="nav-link" aria-current="page">contact</router-link>
              </li>
              <li class="nav-item">
                <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
              </li>
            </ul>
          </div>
        </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-12 mb-4 mb-lg-0">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/187.webp"
                    class="card-img-top"
                    alt="Peaks Against the Starry Sky"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0 d-none d-lg-block">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/188.webp"
                    class="card-img-top"
                    alt="Bridge Over Water"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0 d-none d-lg-block">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/189.webp"
                    class="card-img-top"
                    alt="Purbeck Heritage Coast"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12 mb-4 mb-lg-0">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/187.webp"
                    class="card-img-top"
                    alt="Peaks Against the Starry Sky"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0 d-none d-lg-block">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/188.webp"
                    class="card-img-top"
                    alt="Bridge Over Water"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0 d-none d-lg-block">
                <div class="card">
                <img
                    src="https://mdbcdn.b-cdn.net/img/new/standard/nature/189.webp"
                    class="card-img-top"
                    alt="Purbeck Heritage Coast"
                />
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">
                    Some quick example text to build on the card title and make up the bulk
                    of the card's content.
                    </p>
                    <a href="#!" class="btn btn-primary">Button</a>
                </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        name: 'indexProduct',
        data() {
            return {
                products: [

                ]
            }
        }
    }
</script>
