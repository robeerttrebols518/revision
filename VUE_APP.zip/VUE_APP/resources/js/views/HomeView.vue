<template>
    <div>
        <h1>HomeView.vue</h1>
    </div>
</template>
