<template>
    <div>
        <h1>ProdHome.vue</h1>
    </div>
</template>
