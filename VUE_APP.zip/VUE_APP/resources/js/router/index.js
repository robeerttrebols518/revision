import {createRouter, createWebHistory } from "vue-router";
import Home from "../components/HomeView.vue";
import Contact from "../components/ContactView.vue";
import IndexProduct from "../components/products/IndexView.vue";
import EditProduct from "../components/EditProductView.vue"
const routes = [
    {
        path: "/",
        name: "home",
        component: Home,
    },
    {
        path: "/contact",
        name: "contact",
        component: Contact,
    },
    {
        path: "/indexProduct",
        name: "indexProduct",
        component: IndexProduct,
    },
    {
        path: "/edit/:id",
        name: "editProduct",
        component: EditProduct,
    }
];

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes,
});

export default router;
