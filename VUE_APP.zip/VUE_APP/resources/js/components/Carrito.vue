<template>
    <div>
        <h1>Carrito.vue</h1>
    </div>
</template>
