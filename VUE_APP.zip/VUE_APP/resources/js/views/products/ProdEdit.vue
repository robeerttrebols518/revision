<template>
    <div>
        <h1>ProdEdit.vue</h1>
    </div>
</template>
