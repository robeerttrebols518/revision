<template>
    <div>
        <h1>ProdCreate.vue</h1>
    </div>
</template>
