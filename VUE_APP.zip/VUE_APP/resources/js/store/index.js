import { createStore } from 'vuex'

import axios from "axios";
import Swal from "sweetalert2";

import createPersistedState from "vuex-persistedstate";

export default createStore({
  state: {
    app: {
      name: 'Inventario'
    },
    user: null,
    auth: false,
    productos: [],
    carrito: {},
    role: null,
  },
  mutations: {
    setUserRole(state, role){
      state.role = role;
      console.log(state.role);
    },
    SET_USER(state, user){
      state.user = user;
      state.auth = Boolean(user);
    },
    SetProducto(state, payload){
      state.productos = payload
      console.log(state.productos)
    },
    setCarrito(state, payload){
      state.carrito[payload.id] = payload
    },
    vaciarCarrito(state){
      state.carrito = {}
    },
    aumentar(state, payload){
      state.carrito[payload].cantidad = state.carrito[payload].cantidad + 1
    },
    disminuir(state, payload){
      state.carrito[payload].cantidad = state.carrito[payload].cantidad - 1
      if(state.carrito[payload].cantidad === 0){
        delete state.carrito[payload]
      }
    }
  },
  actions: {
    getUserRole({ commit }){
      axios.get("/api/getRole").then(res => {
        commit('setUserRole', res.data.is_admin);
      }).catch(() => {});
    },
    async logout({ dispatch }){
      await axios.post("/api/logout");
      return dispatch("getUser");
    },
    async login({ dispatch }, credentials){
      await axios.get('/sanctum/csrf-cookie');
      await axios.post("/api/login", credentials)
      .catch((error) => {
        Swal.fire(
          'Error',
          'correo o clave incorrecta',
          'error'
        )
      });
      return dispatch("getUser");
    },
    getUser({ commit }){
      axios.get("/api/user").then(res => {
        commit('SET_USER', res.data);
      }).catch(() => {
        commit('SET_USER', null);
      });
    },
    async fetchData({ commit }){
      try {
        const res = await fetch('api.json')
        const data = await res.json()
        commit('SetProducto', data)
      } catch (error){
        console.log(error)
      }
    },
    agregarAlCarro({ commit, state }, producto){
      state.carrito.hasOwnProperty(producto.id)
        ? producto.cantidad = state.carrito[producto.id].cantidad + 1
        : producto.cantidad = 1
      commit('setCarrito', producto)
    }
  },
  modules: {
  },
  getters: {
    totalCantidad(state){
      return Object.values(state.carrito).reduce((acc, {cantidad}) => acc + cantidad, 0)
    },
    totalPrecio(state){
      return Object.values(state.carrito).reduce((acc, {cantidad, precio}) => acc + cantidad * precio, 0)
    }
  },
  plugins: [createPersistedState()]
})
