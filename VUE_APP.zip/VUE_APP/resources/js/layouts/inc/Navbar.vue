<template>
    <div>
        <h1>Navbar.vue</h1>
    </div>
</template>
