<template>
    <div>
        <h1>CarritoView.vue</h1>
    </div>
</template>
