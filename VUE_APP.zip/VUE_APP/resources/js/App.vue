<template>
    <router-view/>
</template>
