<template>
    <div>
        <h1>AboutView.vue</h1>
    </div>
</template>
