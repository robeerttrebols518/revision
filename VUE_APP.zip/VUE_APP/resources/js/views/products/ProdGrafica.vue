<template>
    <div>
        <h1>ProdGrafica.vue</h1>
    </div>
</template>
